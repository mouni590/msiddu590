package com.cg.utility;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cg.model.CustomersDetail;
import com.cg.model.TransactionDetails;

public class Database {
	public Session getSession() {
		Configuration configuration=new Configuration().configure().addAnnotatedClass(CustomersDetail.class);
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session= sessionFactory.openSession();
		return session;
	}
	
	public Session getSession2() {
		Configuration configuration=new Configuration().configure().addAnnotatedClass(TransactionDetails.class);
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session= sessionFactory.openSession();
		return session;
	}
}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from "@angular/common/http";
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BooksComponent } from './books/books.component';
import { BookListSearchComponent } from './book-list-search/book-list-search.component';
import { BooksPipe } from './books.pipe';
import { FormsModule } from "@angular/forms";
@NgModule({
  declarations: [
    AppComponent,
    BooksComponent,
    BookListSearchComponent,
    BooksPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

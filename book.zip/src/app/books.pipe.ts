import { Pipe, PipeTransform } from '@angular/core';
import { BookInterface } from './book-interface';

@Pipe({
  name: 'books'
})
export class BooksPipe implements PipeTransform {

  transform(Booklists:BookInterface[],searchterm:string): any {
    if(!Booklists||!searchterm)
    return Booklists;
    return Booklists.filter(s=>(s.BookId.toString()==searchterm
    ||s.BookAuthor.toLocaleLowerCase().startsWith(searchterm.toLocaleLowerCase())
    ||s.BookTitle.toLowerCase().startsWith(searchterm.toLowerCase())
    ||s.BookYearOfPublish.toString()==searchterm
    ||s.category.toLowerCase().startsWith(searchterm.toLowerCase())));
  }

}

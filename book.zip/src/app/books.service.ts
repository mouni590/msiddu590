import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { BookInterface } from "./book-interface";
@Injectable({
  providedIn: 'root'
})
export class BooksService {

getBookLists():Observable<BookInterface[]>
{
  return this.http.get<BookInterface[]>("./assets/db.json");
}
  constructor(private http:HttpClient) { }
}

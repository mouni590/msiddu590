import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BooksComponent } from './books/books.component';
import { BookListSearchComponent } from './book-list-search/book-list-search.component';


const routes: Routes = [
  {
    path:'BookList',
    component:BooksComponent
  },
  {
    path:'BookListSearch',
    component:BookListSearchComponent
  },
  {
    path:' ',
    redirectTo:'/BookList',
    pathMatch:'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

export interface BookInterface {
    BookId:string;
    BookTitle:string;
    BookAuthor:string;
    BookYearOfPublish:number;
    category:string;
}

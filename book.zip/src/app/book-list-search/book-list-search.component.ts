import { Component, OnInit } from '@angular/core';
import { BookInterface } from '../book-interface';
import { BooksService } from '../books.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-book-list-search',
  templateUrl: './book-list-search.component.html',
  styleUrls: ['./book-list-search.component.css']
})
export class BookListSearchComponent implements OnInit {
booklists:BookInterface[];
searchterm:string;
usersearch:string;
  constructor(private Bookservice:BooksService,private router:Router) { }

  ngOnInit() {
    this.Bookservice.getBookLists().subscribe((data)=>this.booklists=data)
  }
  onSubmit(){
    this.searchterm=this.usersearch;
  }

}

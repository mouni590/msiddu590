import { Component, OnInit } from '@angular/core';
import { BookInterface } from '../book-interface';
import { BooksService } from '../books.service';
@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BooksComponent implements OnInit {
bookLists:BookInterface[];
  constructor(private bookservice:BooksService) { }

  ngOnInit() {
    this.bookservice.getBookLists().subscribe(data=>this.bookLists=data);
  }
  

}

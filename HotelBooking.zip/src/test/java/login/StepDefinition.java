package login;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.bean.User;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
	WebDriver driver;
    private User objhlpg;
       //private HotelLoginPageFactory objhlpg;
       
    @Given("^User is on 'login' Page$")
    public void user_is_on_login_Page() throws Throwable {
           //driver = new FirefoxDriver();
           
           System.setProperty("webdriver.chrome.driver", "C:/Users/sveyyala/Desktop/chrome/chromedriver_win32/chromedriver.exe");
            driver = new ChromeDriver();

           driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
           objhlpg = new User(driver);

           driver.get("file:///C:/Users/sveyyala/Desktop/hotel%20html/hotelBooking/login.html");
       }
       @When("^user enters invalid UserName$")
       public void user_enters_invalid_UserName() throws Throwable {
           // Write code here that turns the phrase above into concrete actions
           objhlpg.setPfuname("capg");
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
           throw new PendingException();
       }

       @Then("^display 'Please Enter UserName'$")
       public void display_Please_Enter_UserName() throws Throwable {
           // Write code here that turns the phrase above into concrete actions
           String actualTitle = driver.findElement(By.xpath("//*[@id='mainCnt']/div[1]/div[1]/h1")).getText();
           // assertEquals("TestFailed", "Hotel Booking", actualTitle);

           String expectedTitle="Hotel Booking Application";
           if(expectedTitle.equals(actualTitle))
               System.out.println("Page Heading Matched...");
           else
               System.out.println("Page Heading does not matched...");
           driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
           //driver.close();
           //throw new PendingException();
       }



       @When("^user enters invalid password$")
       public void user_enters_invalid_password() throws Throwable {
           // Write code here that turns the phrase above into concrete actions
            objhlpg.setPfpwd("cap456");
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
           throw new PendingException();
       }



       @Then("^display 'Please Enter Password'$")
       public void display_Please_Enter_Password() throws Throwable {
           // Write code here that turns the phrase above into concrete actions
           throw new PendingException();
       }



       @When("^user enters invalid details$")
       public void user_enters_invalid_details() throws Throwable {
           // Write code here that turns the phrase above into concrete actions
           objhlpg.setPfuname("capgem");
           objhlpg.setPfpwd("chan");
           driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
           throw new PendingException();
       }



       @Then("^display 'Invalid Login Please try again'$")
       public void display_Invalid_Login_Please_try_again() throws Throwable {
           // Write code here that turns the phrase above into concrete actions
           throw new PendingException();
       }



       @When("^user enters valid details$")
       public void user_enters_valid_details() throws Throwable {
           // Write code here that turns the phrase above into concrete actions
           objhlpg.setPfuname("capgemini");
           objhlpg.setPfpwd("capg1234");
           driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
           objhlpg.setPflogin();
        // driver.close();
          // throw new PendingException();
       }


       @Then("^display 'HotelBooking' Page$")
       public void display_HotelBooking_Page() throws Throwable {
           // Write code here that turns the phrase above into concrete actions
            driver.navigate().to("file:///C:/Users/sveyyala/Desktop/hotel%20html/hotelBooking/hotelbooking.html");
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            //driver.close();
           //throw new PendingException();
       }

   }
    
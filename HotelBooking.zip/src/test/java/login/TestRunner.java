package login;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="src/main/resources/Login/login.feature",
        glue="login",
        
        plugin="pretty")
public class TestRunner {

}

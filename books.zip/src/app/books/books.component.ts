import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BooksComponent implements OnInit {
  
  constructor (private httpService: HttpClient) { }
  books: string [];
  ngOnInit () {
    this.httpService.get('./assets/bookList.json').subscribe(
      data => {
        this.books = data as string [];	 // FILL THE ARRAY WITH DATA.
       console.log(this.books[1]);
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );
    }

}

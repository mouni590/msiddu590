import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  id2: number;
  name2: string;
  sal1: number;
  dept1: string;
  arr:any[]=[];
add(id1:number,name1:string,sal:number,dept:string)
{
  
  this.id2=id1;
  this.name2=name1;
  this.sal1=sal;
  this.dept1=dept; 
   this.arr.push(this.id2);
  this.arr.push(this.name2);
  this.arr.push(this.sal1);
  this.arr.push(this.dept1);
  console.log(this.arr);
 alert(this.arr);
}
}

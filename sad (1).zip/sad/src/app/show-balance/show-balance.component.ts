import { Component, OnInit } from '@angular/core';
import { BankServiceService } from '../bank-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-show-balance',
  templateUrl: './show-balance.component.html',
  styleUrls: ['./show-balance.component.css']
})
export class ShowBalanceComponent implements OnInit {

  constructor(private router: Router, private userService:BankServiceService) { }

  ngOnInit() {
  }
 balance : number;
  
  showbalance(){
    this.userService.showbalance().subscribe(data=>{
      //this.userService.setAccountNumber(data);
      this.balance=data;
   
      },error=>{alert("Incorrect Account Number")});
  };
}

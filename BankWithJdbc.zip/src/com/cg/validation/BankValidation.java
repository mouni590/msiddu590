package com.cg.validation;

public class BankValidation {
public boolean phnnum(long l1) {
		
		boolean phnnum = Long.toString(l1).matches("^[0-9]{10}$");
		if(phnnum)
			return true;
		return false;
	}

	public boolean aadnum(long l2) {
		
		boolean adnum = Long.toString(l2).matches("^[0-9]{12}$");
		if(adnum)
			return true;
		return false;
	}


}

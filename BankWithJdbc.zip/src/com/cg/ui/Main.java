package com.cg.ui;

import java.util.Scanner;

import com.cg.service.BankService;


public class Main {
	private static BankService service = new BankService();
	private static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		
		System.out.println("<****Welcome to BANK SERVICES****>");
		long accountnumber;
		while(true)
		{
			System.out.println("Please Enter Your Choice\n1.Create Your Bank Account\n2.Show Balance\n3.Deposit\n4.Withdraw\n5.Fund Transfer\n6.Print Transactions\n7.Exit");
			int ch = sc.nextInt();
			switch(ch)
			{
			
			case 1 : 
				service.saveCustomerInfo();
				break;
			case 2 :
				System.out.println("Enter Account Number:");
				accountnumber = sc.nextLong();
				System.out.println("The Account details are:\n"+service.showBalance(accountnumber));
				break;
			case 3 :
				System.out.println("Enter Account Number:");
				accountnumber= sc.nextLong();
				System.out.println("Enter the amount to be deposited:");
				double money1 = sc.nextDouble();
				service.depositAmount(accountnumber, money1);
				break;
			case 4 :
				System.out.println("Enter Account Number:");
				accountnumber = sc.nextLong();
				System.out.println("Enter Amount to withdraw:");
				double money = sc.nextDouble();
				service.withdrawAmount(accountnumber, money);
				break;
			case 5 :
				System.out.println("Enter Sender Account Number:");
				long senderaccountnum = sc.nextLong();
				System.out.println("Enter Reciever Account Number:");
				long recieveraccountnum = sc.nextLong();
				System.out.println("Enter ammount to be transfered:");
				long amountToTransfer = sc.nextLong();
				System.out.println(service.fundTransfer(senderaccountnum, recieveraccountnum, amountToTransfer));
				break;
			case 6:
				System.out.println("Enter Account Number:");
				accountnumber = sc.nextLong();
				System.out.println("The Transactions are:\n"+service.printTransactions(accountnumber));
				break;
			case 7:
				System.out.println("Thank you!!!");
			    System.exit(0);
			    break;
			default :
				System.out.println("Please enter valid choice");
				break;
	
	 		}
			
		}
	}
}

package com.cg.emp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.emp.bean.Employee;
import com.cg.emp.exception.EmployeeException;
import com.cg.emp.service.EmployeeService;

@Controller
public class EmployeeController {
	@Autowired
	EmployeeService employeeService;
	@RequestMapping("/")
	public ModelAndView home()
	{
		ModelAndView mv;
		try {
			List<Employee> employees=employeeService.getAllEmployee();
			mv=new ModelAndView("index");
			mv.addObject("employees", employees);
			return mv;
		} catch (EmployeeException e) 
		{
			mv=new ModelAndView("error");
			     mv.addObject("err", e);
			     return mv;
		}
		
		
	}
	@RequestMapping("/delete")
    public ModelAndView deleteEmployee(@RequestParam int id) {
		ModelAndView mv;
		try {
		List<Employee> employees=employeeService.deleteEmployee(id);
		mv=new ModelAndView("index");
		mv.addObject("employees", employees);
		return mv;
		}catch(EmployeeException e) {
			mv=new ModelAndView("error");
		     mv.addObject("err", e);
		     return mv;
		}
	 
 }
}

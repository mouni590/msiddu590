package com.cg.emp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.emp.bean.Employee;
import com.cg.emp.exception.EmployeeException;
@Repository
public class EmployeeDaoImpl  implements EmployeeDao{
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public List<Employee> getAllEmployee() throws EmployeeException {
		TypedQuery<Employee> query=entityManager.createQuery("from Employee order by id", Employee.class);
		return query.getResultList();

	}
	@Override
	public List<Employee> deleteEmployee(int id) throws EmployeeException {
		try {
		Employee emp=entityManager.find(Employee.class, id);
		entityManager.remove(emp);
		return getAllEmployee();
	}
		catch(Exception ex) {
			throw new EmployeeException(ex.getMessage());
		}
		}
}

package com.cg.capg;


	import org.springframework.context.ApplicationContext;
	import org.springframework.context.support.ClassPathXmlApplicationContext;

	public class Main1 {
	public static void main(String[]args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("Beans.xml");
		Employee1 emp=(Employee1)context.getBean("employee1");
		System.out.println(emp);
	}
	}


package com.capg;

public class Employee {
   private int empId;
   private String empName;
   private double salary;
   private String businessunit;
   private int age;
/*public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public double getSalary() {
	return salary;
}

public void setSalary(double salary) {
	this.salary = salary;
}
public String getBusinessunit() {
	return businessunit;
}
public void setBusinessunit(String businessunit) {
	this.businessunit = businessunit;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
   public Employee() {
	  
   }
   public Employee(int empId) {
	  
	   this.empId=empId;
   }
   public Employee(int empId,String empName) {
	   
	   this.empId=empId;
	   this.empName=empName;
   }
   public Employee(int empId,String empName,double salary) {
	   this.empId=empId;
	   this.empName=empName;
	   this.salary=salary;
   }
   public Employee(int empId,String empName,double salary,String businessunit) {
	   this.empId=empId;
	   this.empName=empName;
	   this.salary=salary;
	   this.businessunit=businessunit;
   }*/
 public Employee(int empId,String empName,double salary,String businessunit,int age) {
	   this.empId=empId;
	   this.empName=empName;
	   this.salary=salary;
	   this.businessunit=businessunit;
	   this.age=age;
   }


@Override
public String toString() {
	return "Employee [empId=" + empId + ", empName=" + empName + ", salary=" + salary + ", businessunit=" + businessunit
			+ ", age=" + age + "]";
	}

}

package com.capg.assign;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main2 {
  public static void main(String[]args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("Beans.xml");
		SBU1 sbuu1=(SBU1)context.getBean("sbu");
		System.out.println(sbuu1);
	}
	}




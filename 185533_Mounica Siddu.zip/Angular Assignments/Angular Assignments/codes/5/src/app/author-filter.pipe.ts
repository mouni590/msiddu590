import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'authorFilter'
})
export class AuthorFilterPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
     return value.filter((data)=>data.author.indexOf(args)!==-1);
  }

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'LAB3';
  name: "Sneha";
  RId: number;
  RName: string="";
  RSal: number;
  RDept: string="";
  RUpdated;
employees=[
    {
      'empId': 185539,
      'empName':'mounica',
      'empSal': 200000,
      'empDept':'IT'
    },
    {
      'empId': 182213,
      'empName':'srija',
      'empSal': 6000000,
      'empDept':'IT'
    },
    {
      'empId': 185497,
      'empName':'Tinku',
      'empSal': 5000000,
      'empDept':'EEE'
    }

  ];
  updateEmployee(finalid:number,finalname:string,finalsal:number,finaldep:string){
    this.RUpdated.empId=finalid;
    this.RUpdated.empName=finalname;
    this.RUpdated.empSal=finalsal;
    this.RUpdated.empDept=finaldep;
  }
  
  update(res){
    this.RId=res.empId;
    this.RName=res.empName;
    this.RSal=res.empSal;
    this.RDept=res.empDept;
    this.RUpdated=res;
  }
  add(fid:number,fname:string,fsal:number,fdept:string){
    let textbox= fid;
    let textbox2=fname;
    let textbox3=fsal;
    let textbox4=fdept;
    this.employees.push({ 'empId': textbox,'empName':textbox2,'empSal':textbox3,'empDept':textbox4});


  }
  delete(res1, n){
    this.employees.splice(n, 0);
  }

}


class Mobile{
    arr:any = [];
    mobileId:number;
    mobileName:string;
    mobileCost:number;
    constructor(id:number,name:string,cost:number)
    {
        this.mobileId=id;
        this.mobileName=name;
        this.mobileCost=cost;
   
    }
   printMobileDetail()
    {
       this.arr.push(this.mobileId);
       this.arr.push(this.mobileName);
       this.arr.push(this.mobileCost);
       console.log(this.arr);
    }
   }

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var mobile = /** @class */ (function () {
    function mobile(id, name, cost) {
        this.arr = [];
        this.mobileId = id;
        this.mobileName = name;
        this.mobileCost = cost;
    }
    mobile.prototype.printMobileDetail = function () {
        this.arr.push(this.mobileId);
        this.arr.push(this.mobileName);
        this.arr.push(this.mobileCost);
        console.log(this.arr);
    };
    return mobile;
}());
var smartPhone = /** @class */ (function (_super) {
    __extends(smartPhone, _super);
    function smartPhone(id, name, cost, type) {
        var _this = _super.call(this, id, name, cost) || this;
        _this.mobileType = type;
        return _this;
    }
    smartPhone.prototype.printMobileDetail = function () {
        this.arr.push(this.mobileId);
        this.arr.push(this.mobileName);
        this.arr.push(this.mobileCost);
        this.arr.push(this.mobileType);
        console.log(this.arr);
    };
    return smartPhone;
}(mobile));
var smartPh = new mobile(111111, "Lenovo", 2297);
smartPh.printMobileDetail();
var tom = new smartPhone(22222, "Hp", 8364, "macOs");
tom.printMobileDetail();
var tom1 = new smartPhone(333333, "Moto", 4784, "kitkat");
tom1.printMobileDetail();

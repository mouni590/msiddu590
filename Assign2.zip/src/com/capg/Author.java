package com.capg;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;


@Entity
public class Author {
	@Id
	private int Id;
	private String name;
	
@ManyToMany
private List<Book> book=new ArrayList<>();

	
	
	
	

	@Override
public String toString() {
	return "Author [Id=" + Id + ", name=" + name + "]";
}
	public List<Book> getBook() {
	return book;
}
public void setBook(List<Book> book) {
	this.book = book;
}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	

}

package com.capg;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class MainClass {

	public static void main(String[] args) {
	
		Book b=new Book();
		b.setISBN(25);
		b.setTitle("How to Write a Program");
		b.setPrice(10000);
		Book b1=new Book();
		b1.setISBN(24);
		b1.setTitle("Second Book");
		b1.setPrice(700);
		Book b3=new Book();
		b3.setISBN(26);
		b3.setTitle("Third Book");
		b3.setPrice(600);
		Book b4=new Book();
		b4.setISBN(27);
		b4.setTitle("3rd Book");
		b4.setPrice(900);
		Author a =new Author();
		a.setId(1001);
		a.setName("Mounica");
		Author a1=new Author();
		a1.setId(1002);
		a1.setName("Srija");
		a.getBook().add(b);
		a.getBook().add(b1);
		a1.getBook().add(b3);
		a1.getBook().add(b4);
		b.getAuthor().add(a);
		b.getAuthor().add(a1);
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factory.createEntityManager();
		em.getTransaction().begin();
		em.persist(b);
		em.persist(b1);
		em.persist(b3);
		em.persist(b4);
		
		em.persist(a);
		em.persist(a1);
		TypedQuery<Book> query=em.createQuery("from Book", Book.class);
		List<Book> bk=query.getResultList();
		for (Book book : bk) {
			System.out.println(book.toString());
		}
		TypedQuery<Book> query3=em.createQuery("from Book where price BETWEEN 500 AND 1000", Book.class);
		List<Book> bk3=query3.getResultList();
		for (Book book : bk3) {
			System.out.println(book.toString());
		}
		
		em.getTransaction().commit();
		System.out.println("Done");
	}

}

package com.cg.service;

import java.util.List;

import com.cg.bean.Customer;
import com.cg.exception.CustomerException;



public interface CustomerService
{
	public boolean addCustomer(Customer cust) throws CustomerException;
	   

   
    public Customer loginByUsername(String username, String password) throws CustomerException;
   
    public double depositMoney(int accountNo, double amount) throws CustomerException;
   
    public double withdrawMoney(int accountNo,double amount) throws CustomerException;
   
    public double showBalance(int accountNo) throws CustomerException;
   
    public String  fundTransferUpdate(int accountNo1,int accountNo2,double amount) throws CustomerException;

	Customer getCustomerDetails(int accountNo) throws CustomerException;

}

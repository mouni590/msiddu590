package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Customer;
import com.cg.dao.BankDao;
import com.cg.exception.CustomerException;
@Service
public class CustomerServiceImpl implements CustomerService
{
	@Autowired
	BankDao bankdao;

	@Override
	public boolean addCustomer(Customer cust) throws CustomerException {
		
			try {
				bankdao.save(cust);
			return	true;
			}
			catch(Exception ex)
			{
				throw new CustomerException("Check the details properly");
			}
	}

	@Override
	public Customer getCustomerDetails(int accountNo) throws CustomerException {
		try
		{
		return bankdao.getCustomerByAccountNo(accountNo);
		}
		catch(Exception ex)
		{
			throw new CustomerException("Pleas enter valid account number");
		}
	}

	@Override
	public Customer loginByUsername(String username, String password) throws CustomerException {
		try
		{
			Customer cust=bankdao.getCustomerByUsername(username);
		return cust;
		}
		catch(Exception ex)
		{
			throw new CustomerException("Pleas enter valid username and password");
		}
	}

	@Override
	public double depositMoney(int accountNo, double amount) throws CustomerException
	{
		try{
			Customer cust=bankdao.getCustomerByAccountNo(accountNo);
		
		double remBal=cust.getBalance()+amount;
		cust.setBalance(remBal);
	     bankdao.save(cust);
	     return cust.getBalance();
		}
		catch(Exception ex)
		{
			throw new CustomerException("Pleas enter valid account number and password");
		}
		
	}

	@Override
	public double withdrawMoney(int accountNo, double amount) throws CustomerException {
		// TODO Auto-generated method stub
		try
		{
		Customer cust=bankdao.getCustomerByAccountNo(accountNo);
		double remBal=cust.getBalance()-amount;
		 cust.setBalance(remBal);
	     bankdao.save(cust);
		return cust.getBalance();
		}
		catch(Exception ex)
		{
			throw new CustomerException("Pleas enter valid account number and password");
		}
	}

	@Override
	public double showBalance(int accountNo) throws CustomerException {
		try
		{
		Customer cust=bankdao.getCustomerByAccountNo(accountNo);
		return cust.getBalance();
		}
		catch(Exception ex)
		{
			throw new CustomerException("Pleas enter valid account number");
		}
		
	}

	@Override
	public String fundTransferUpdate(int accountNo1, int accountNo2, double amount) throws CustomerException {
		try {
		Customer cust1=bankdao.getCustomerByAccountNo(accountNo1);
		double remBal1=(cust1.getBalance()-amount);
		cust1.setBalance(remBal1);
		  bankdao.save(cust1);
		Customer cust2=bankdao.getCustomerByAccountNo(accountNo2);
		double remBal2=cust2.getBalance()+amount;
		cust2.setBalance(remBal2);
		bankdao.save(cust2);
		return "Changes Done Scuccessfully";
		}
		catch(Exception ex)
		{
			throw new CustomerException("Pleas enter valid source and destination files correct");
		}
	}

}

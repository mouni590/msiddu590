package com.cg.controller;



import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Customer;
import com.cg.exception.CustomerException;
import com.cg.service.CustomerService;

@RestController
public class CustomerController
{
	@Autowired
	CustomerService customerService;
      @RequestMapping(value = "/customer", method = RequestMethod.POST)
	public boolean addCustomer(@RequestBody Customer cust) throws CustomerException {
		return customerService.addCustomer(cust);
	}
      @RequestMapping(value = "/showbal/{accountNo}")
  	public double showBalance(@PathVariable int accountNo) throws CustomerException {
  		return customerService.showBalance(accountNo);
  	}
      @RequestMapping(value = "/login/{username}/{password}")
    	public Customer lo(@PathVariable String username,@PathVariable String password) throws CustomerException {
    		return customerService.loginByUsername(username, password);
    	}
    @RequestMapping(value = "/getCustomerByAccNo/{accountNo}")
	public Customer getCustomer(@PathVariable int accountNo) throws CustomerException {
		return customerService.getCustomerDetails(accountNo);
	}
	@PutMapping("/customersdeposit/{accountNo}/{amount}")
	public double depositMoney(@PathVariable int accountNo, @PathVariable double amount) throws CustomerException {
		return customerService.depositMoney(accountNo,amount);
	}
	@PutMapping("/customerswithdrawl/{accountNo}/{amount}")
	public double withdrawMoney(@PathVariable int accountNo, @PathVariable double amount) throws CustomerException {
		return customerService.withdrawMoney(accountNo,amount);
	}
	@PutMapping("/customerswithdrawl/{source}/{destination}/{amount}")
	public String fundTransferUpdate(@PathVariable int source,@PathVariable int destination, @PathVariable long amount) throws CustomerException {
		return customerService.fundTransferUpdate(source,destination,amount);
	}
}

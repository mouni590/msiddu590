package com.ui;
import java.util.Scanner;
public class Main {  
	 	public static void main(String args[]) {
	int ch;
	BankModule bankModules = new BankModule();
	Scanner sc = new Scanner(System.in);
	while(true){
	System.out.println("\n ------------------\n 1. Create Account \n 2. Show Balance \n 3. Deposit \n 4. Withdraw \n 5. Fund Transfer \n 6. Print Transactions \n 7. Exit\n------------------------");
	System.out.print("Enter your choice : ");
	ch = sc.nextInt(); 
	switch(ch) {
	case 1:
	bankModules.createAccount(); 
	break;
	case 2: 
	bankModules.showBalance(); 
	break;
	case 3: 
	bankModules.deposit();
	break;
	case 4:
	bankModules.withdraw();
	break;
	case 5: 
	bankModules.fundTransfer();
	break;
	case 6:
	bankModules.printTransactions();
	break;
	case 7:
		System.out.println("Thank You !");
	    System.exit(0);
	    break;
	
	}
}
	}
}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {HttpClientModule} from '@angular/common/http';
import { BookFilterPipe } from './book-filter.pipe';
import { BooksComponent } from './books/books.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { AuthorFilterPipe } from './author-filter.pipe';
import { YearFilterPipe } from './year-filter.pipe';
@NgModule({
  declarations: [
    AppComponent,
    BookFilterPipe,
    BooksComponent,
    WelcomeComponent,
    AuthorFilterPipe,
    YearFilterPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

package com.cg.bank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bank.bean.Customer;
import com.cg.bank.exception.CustomException;
import com.cg.bank.service.CustomService;
import com.cg.bank.service.TransactionService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class CustomController {
	@Autowired
	TransactionService ts;
	@Autowired
	CustomService customService;
      @RequestMapping(value = "/customer", method = RequestMethod.POST)
	public boolean addCustomer(@RequestBody Customer cust) throws CustomException {
		return customService.addCustomer(cust);
	}
      @RequestMapping(value = "/showbal/{accountNo}")
  	public double showBalance(@PathVariable int accountNo) throws CustomException {
  		return customService.showBalance(accountNo);
  	}
      @RequestMapping(value = "/login/{username}/{password}")
    	public int login(@PathVariable String username,@PathVariable String password) throws CustomException {
    		return customService.loginByUsername(username, password);
    	}
    @RequestMapping(value = "/getCustomerByAccNo/{accountNo}")
	public Customer getCustomer(@PathVariable int accountNo) throws CustomException {
		return customService.getCustomerDetails(accountNo);
	}
	@PutMapping("/deposit/{accountNo}/{amount}")
	public double depositMoney(@PathVariable int accountNo, @PathVariable double amount) throws CustomException {
		ts.addTransaction("Amount="+amount+"is added to account having account number "+accountNo,accountNo);
		return customService.deposit(accountNo,amount);
	}
	@PutMapping("/withdrawl/{accountNo}/{amount}")
	public double withdrawMoney(@PathVariable int accountNo, @PathVariable double amount) throws CustomException {
		ts.addTransaction("Amount "+amount+" debited from account "+accountNo, accountNo);
		return customService.withdraw(accountNo,amount);
	}
	@PutMapping("/Transfer/{source}/{destination}/{amount}")
	public String fundTransferUpdate(@PathVariable int source,@PathVariable int destination, @PathVariable long amount) throws CustomException {
		ts.addTransaction("Amount "+amount+" id added to account having account number "+source, source);
		ts.addTransaction("Amount "+amount+" debited from account "+destination, destination);
		
		
		return customService.fundTransfer(source,destination,amount);
	}
	@RequestMapping("/getTransactions/all/{id}")
    public List<String> getTransactions(@PathVariable int id) {
        return ts.getTransaction(id);
    }
}
